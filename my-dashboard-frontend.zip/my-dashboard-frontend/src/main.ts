import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Route } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { importProvidersFrom } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http'; // Impor HttpClientModule
import { RouterModule } from '@angular/router'; // Impor RouterModule
import { DashboardComponent } from './app/pages/dashboard/dashboard.component';
import { TambahUserComponent } from './app/pages/tambah-user/tambah-user.component';
import { LoginComponent } from './app/pages/login/login.component';
import { AuthGuard } from './app/auth.guard';
import { UserComponent } from './app/pages/user/user.component';
import { UpdateProfileComponent } from './app/pages/update-profile/update-profile.component';
import { authInterceptor } from './app/auth.interceptor';

const routes: Route[] = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'users', component: UserComponent, canActivate: [AuthGuard] },
  { path: 'tambah-user', component: TambahUserComponent, canActivate: [AuthGuard] },
  { path: 'update-profile/:id', component: UpdateProfileComponent, canActivate: [AuthGuard] },
];

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor])),
    importProvidersFrom(
      BrowserAnimationsModule,
      HttpClientModule,
      RouterModule
    )
  ]
}).catch(err => console.error(err));
