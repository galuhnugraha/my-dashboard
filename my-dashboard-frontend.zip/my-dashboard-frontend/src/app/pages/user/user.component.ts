import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user',
  standalone: true,
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
  imports: [CommonModule] // Tambahkan CommonModule di sini
})
export class UserComponent {
  data: any[] = [];
  private apiUrl = 'http://localhost:3000/api/v1/users/users'; // Ganti dengan URL API Anda
  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.fetchData();
  }

  fetchData() {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.getData(headers).subscribe(
      (response: any) => {
        this.data = response;
      },
      (error) => {
        console.error('Error fetching data', error);
        alert('Failed to fetch data.');
      }
    );
  }

  getData(headers: HttpHeaders): Observable<any> {
    return this.http.get<any>(this.apiUrl, { headers });
  }

  goToAddUser() {
    this.router.navigate(['/tambah-user']);
  }

  editUser(userId: number): void {
    this.router.navigate([`/update-profile/${userId}`]);
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.http.delete(`${this.apiUrl}/${userId}`).subscribe(
        () => {
          this.data = this.data.filter(user => user.id !== userId);
          console.log('User deleted successfully');
        },
        error => console.error('Error deleting user', error)
      );
    }
  }
}
