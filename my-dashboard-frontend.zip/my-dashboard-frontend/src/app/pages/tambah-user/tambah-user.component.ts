import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tambah-user',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './tambah-user.component.html',
  styleUrls: ['./tambah-user.component.css'] // Perbaiki nama properti styleUrls
})
export class TambahUserComponent {
  private apiUrl = 'http://localhost:3000/api/v1/users/register'; // Ganti dengan URL API Anda

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.http.post<any>(this.apiUrl, form.value).subscribe(
        (response) => {
          console.log('User added successfully', response);
          form.reset(); // Reset form setelah submit
          this.router.navigate(['/user']); // Redirect ke halaman User setelah submit
        },
        (error) => {
          console.error('Error adding user', error);
          // Tambahkan penanganan error sesuai kebutuhan
        }
      );
    }
  }
}
