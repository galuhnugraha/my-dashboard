import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css'],
  standalone: true,
  imports: [FormsModule] // Pastikan FormsModule diimpor di sini
})
export class UpdateProfileComponent implements OnInit {
  user = {
    id: '',
    fullname: '',
    email: ''
  };

  private apiUrl = 'http://localhost:3000/api/v1/users/users'; // Ganti dengan URL API Anda

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) { }

  ngOnInit() {
    const userId = this.route.snapshot.paramMap.get('id');
    if (userId) {
      this.loadUserData(userId);
    }
  }

  loadUserData(id: string) {
    this.http.get<any>(`${this.apiUrl}/${id}`).subscribe(
      (data) => {
        this.user = data;
      },
      (error) => {
        console.error('Error loading user data', error);
      }
    );
  }

  updateUser() {
    this.http.put(`${this.apiUrl}/${this.user.id}`, this.user).subscribe(
      () => {
        this.router.navigate(['/user']);
      },
      (error) => {
        console.error('Error updating user data', error);
      }
    );
  }
}
