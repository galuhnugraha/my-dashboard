import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [FormsModule]
})
export class LoginComponent {
  loginData = {
    email: '',
    password: ''
  };

  // http://localhost:3000/api/v1/users
  private apiUrl = 'http://localhost:3000/api/v1/users/login'; // Ganti dengan URL API login Anda

  constructor(private http: HttpClient, private router: Router) { }

  onSubmit() {
    // Kirim data login ke server
    this.login(this.loginData).subscribe(
      (response: any) => {
        console.log(response,'response')
        // Simpan token di localStorage jika login berhasil
        localStorage.setItem('authToken', response.token);
        // Navigasi ke dashboard setelah login
        this.router.navigate(['/dashboard']).then(success => {
          if (success) {
            console.log('Navigation to dashboard successful');
          } else {
            console.error('Navigation to dashboard failed');
          }
        });
      },
      (error) => {
        console.error('Login failed', error);
        // Tampilkan pesan error jika login gagal
        alert('Login failed. Please check your credentials.');
      }
    );
  }

  login(data: { email: string; password: string }): Observable<any> {
    return this.http.post<any>(this.apiUrl, data);
  }
}
