import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    // Logika untuk memeriksa apakah pengguna sudah login
    const token = localStorage.getItem('authToken');

    if (token) {
      // Jika token ada, izinkan akses
      return true;
    } else {
      // Jika token tidak ada, arahkan ke halaman login
      this.router.navigate(['/login']);
      return false;
    }
  }
}
