import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
  imports: [CommonModule]  // Tambahkan CommonModule di sini
})
export class SidebarComponent {
  isLoggedIn = false;

  constructor(private router: Router) { }

  ngOnInit() {
    this.updateLoginStatus();
  }

  // Mengecek apakah user sudah login
  updateLoginStatus() {
    this.isLoggedIn = !!localStorage.getItem('authToken');
  }

  logout() {
    localStorage.removeItem('authToken');
    this.updateLoginStatus();
    this.router.navigate(['/login']);
  }
}
