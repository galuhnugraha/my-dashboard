import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // Ambil token dari localStorage
  const authToken = localStorage.getItem('authToken');

  // Jika token ada, tambahkan ke header Authorization
  if (authToken) {
    const authReq = req.clone({
      setHeaders: { Authorization: `Bearer ${authToken}` }
    });
    return next(authReq);
  }

  // Jika tidak ada token, lanjutkan dengan request asli
  return next(req);
};
