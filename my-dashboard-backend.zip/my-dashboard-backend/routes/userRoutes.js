const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const authenticateJWT = require('../middleware/auth');

const router = express.Router();

// Registrasi pengguna
router.post('/register', async (req, res) => {
    const { fullname, email, password } = req.body;

    try {
        // Cek jika email sudah ada
        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already in use' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await User.create({
            fullname,
            email,
            password: hashedPassword
        });

        // Menghapus field yang tidak diinginkan dari response
        const userResponse = newUser.toJSON();
        delete userResponse.password;

        res.status(201).json({ message: 'User created successfully', user: userResponse });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Login pengguna
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Temukan pengguna berdasarkan email
        const user = await User.findOne({ where: { email } });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Periksa password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid password' });
        }

        // Buat token JWT
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        const userResponse = user.toJSON();
        delete userResponse.password;

        res.status(200).json({ message: 'Login successful', token, data: userResponse });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Mendapatkan semua pengguna
router.get('/users', async (req, res) => {
    try {
        const users = await User.findAll();
        const userResponse = users.map(user => {
            const userData = user.toJSON();
            delete userData.password; // Hapus field password dari response
            return userData;
        });
        res.status(200).json(userResponse);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Mendapatkan pengguna berdasarkan ID
router.get('/users/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        const userResponse = user.toJSON();
        delete userResponse.password; // Hapus field password dari response
        res.status(200).json(userResponse);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Mengupdate pengguna (menggunakan middleware autentikasi)
router.put('/users/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;
    const { fullname, email, password } = req.body;

    try {
        // Cek jika pengguna yang mengupdate data adalah pemilik data atau admin (opsional)
        // if (req.user.id !== parseInt(id)) return res.status(403).json({ message: 'Forbidden' });

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const updatedData = { fullname, email };
        if (password) {
            updatedData.password = await bcrypt.hash(password, 10);
        }

        await user.update(updatedData);
        const userResponse = user.toJSON();
        delete userResponse.password; // Hapus field password dari response

        res.status(200).json({ message: 'User updated successfully', user: userResponse });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Menghapus pengguna (menggunakan middleware autentikasi)
router.delete('/users/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;

    try {
        // Cek jika pengguna yang menghapus data adalah pemilik data atau admin (opsional)
        // if (req.user.id !== parseInt(id)) return res.status(403).json({ message: 'Forbidden' });

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        await user.destroy();
        res.status(204).end();
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
