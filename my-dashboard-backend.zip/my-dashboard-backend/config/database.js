const { Sequelize } = require('sequelize');

// // Inisialisasi Sequelize local
const sequelize = new Sequelize('db_dashboard', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
});

// production
// const sequelize = new Sequelize(process.env.DB_DBNAME,process.env.DB_USER,process.env.DB_PASSWORD, {
//     host: process.env.DB_HOST,
//     dialect: 'mysql',
//   });

module.exports = sequelize;
