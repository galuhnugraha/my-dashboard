// middleware/auth.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');

module.exports = async function(req, res, next) {
    // Ambil token dari header Authorization
    const authHeader = req.header('Authorization');

    // Pastikan token ada
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Token tidak valid, otorisasi ditolak.', status: 401 });
    }

    // Ambil token dari header
    const token = authHeader.split(' ')[1];

    try {
        // Verifikasi token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Cari user berdasarkan ID yang ada dalam token
        const user = await User.findByPk(decoded.id);

        if (!user) {
            return res.status(401).json({ message: 'Token tidak valid, otorisasi ditolak.', status: 401 });
        }

        // Simpan informasi user dalam req untuk digunakan di endpoint berikutnya
        req.user = user;
        next();
    } catch (err) {
        console.error('Error verifikasi token:', err.message);
        if (err.name === 'JsonWebTokenError') {
            return res.status(401).json({ message: 'Token JWT tidak valid, otorisasi ditolak.' });
        }
        res.status(500).json({ message: 'Terjadi kesalahan dalam verifikasi token.' });
    }
};
